package com.example.assetwatch_v1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddSupplier extends AppCompatActivity {

    EditText ET_SupplierName, ET_CompTradeNum, ET_SupplierEmail, ET_SupplierPhone, ET_SupplierAddress, ET_SupplierWebsite;
    Button btn_AddSupplier;
    ImageView IV_BackArrow;
    DatabaseReference userDBRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_supplier);

        ET_SupplierName = (EditText) findViewById(R.id.ET_SupplierName);
        ET_CompTradeNum = (EditText) findViewById(R.id.ET_CompTradeNum);
        ET_SupplierEmail = (EditText) findViewById(R.id.ET_SupplierEmail);
        ET_SupplierPhone = (EditText) findViewById(R.id.ET_SupplierPhone);
        ET_SupplierAddress = (EditText) findViewById(R.id.ET_SupplierAddress);
        ET_SupplierWebsite = (EditText) findViewById(R.id.ET_SupplierWebsite);
        IV_BackArrow = (ImageView) findViewById(R.id.IV_BackArrow);
        btn_AddSupplier = (Button) findViewById(R.id.btn_AddSupplier);

        userDBRef = FirebaseDatabase.getInstance("https://assetwatch-v1-f95c0-default-rtdb.firebaseio.com/").getReference().child("Suppliers");
        IV_BackArrow.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), HomeScreen.class)));
        btn_AddSupplier.setOnClickListener(v -> {
            insertSupplierData();
            startActivity(new Intent(getApplicationContext(), SupplierList.class)); // Should actually then go into Asset List page (which can navigate back to add asset).
        });
        // OnClick Listeners

        //IV_BackArrow.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), HomeScreen.class)));
    }

    private void insertSupplierData() {

        String Supp_name = ET_SupplierName.getText().toString();
        String Trade_num = ET_CompTradeNum.getText().toString();
        String phone = ET_SupplierEmail.getText().toString();
        String email = ET_SupplierPhone.getText().toString();
        String address = ET_SupplierAddress.getText().toString();
        String website = ET_SupplierWebsite.getText().toString();

        SupplierModel supplierModel = new SupplierModel(Supp_name, Trade_num, phone, email, address, website);

        userDBRef.push().setValue(supplierModel);
        Toast.makeText(AddSupplier.this, "Supplier Registered", Toast.LENGTH_SHORT).show();
    }
}