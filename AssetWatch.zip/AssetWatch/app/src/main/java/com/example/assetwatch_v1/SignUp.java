package com.example.assetwatch_v1;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class SignUp extends AppCompatActivity {
    public static final String TAG = "TAG";

    // References elements in the layout.

    EditText ET_Username, ET_Email, ET_Phone, ET_Password, ET_ConPassword;
    Button btn_SignUp;
    ImageView IV_BackArrow, IV_FacebookIcon;
    TextView TV_SignIn;
    DatabaseReference userDBRef;
    FirebaseFirestore fstore;
    String userID;


    private GoogleSignInClient mGoogleSignInClient;
    private static final int RC_SIGN_IN = 1;
    private FirebaseAuth mAuth;

    //google sign in function
    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser user = mAuth.getCurrentUser();
        if (user!=null)
        {
            //takes user to the homescreen
            Intent intent = new Intent(getApplicationContext(), HomeScreen.class);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        fstore = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // Hooks

        IV_BackArrow = findViewById(R.id.IV_BackArrow);
        ET_Username = findViewById(R.id.ET_Username);
        IV_FacebookIcon = findViewById(R.id.IV_FacebookIcon);
        ET_Email = findViewById(R.id.ET_Email);
        ET_Phone = findViewById(R.id.ET_Phone);
        ET_Password = findViewById(R.id.ET_Password);
        ET_ConPassword = findViewById(R.id.ET_ConPassword);
        btn_SignUp = findViewById(R.id.btn_SignUp);
        TV_SignIn = findViewById(R.id.TV_SignIn);

        userDBRef = FirebaseDatabase.getInstance("https://assetwatch-v1-f95c0-default-rtdb.firebaseio.com/").getReference().child("Users");

        TV_SignIn.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), Login.class)));

        mAuth = FirebaseAuth.getInstance();


        // OnClick listeners.

        IV_BackArrow.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), Login.class)));

        IV_FacebookIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createRequest();
                signIn();
            }
        });

        btn_SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = ET_Email.getText().toString().trim();
                String password = ET_Password.getText().toString().trim();
                String con_password = ET_ConPassword.getText().toString().trim();
                String username = ET_Username.getText().toString().trim();
                String phone = ET_Phone.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    ET_Email.setError("Email is Required");
                    return;
                }

                if(TextUtils.isEmpty(password)){
                    ET_Password.setError("Password is Required");
                    return;
                }

                if(password.length() < 7){
                    ET_Password.setError("Password needs more than 7 characters");
                    return;
                }
                if(con_password.length() < 7){
                    ET_Password.setError("Passwords do not match");
                    return;
                }
                //userDBRef.push();

                mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(SignUp.this, "User created", Toast.LENGTH_SHORT).show();
                            userID = mAuth.getCurrentUser().getUid();
                            DocumentReference documentReference = fstore.collection("Users").document(userID);
                            Map<String,Object> user = new HashMap<>();
                            user.put("uName", username);
                            user.put("email", email);
                            user.put("phone", phone);
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Log.d(TAG, "onSuccess: + user profile is created for " + userID );

                                }
                            });
                            startActivity(new Intent(getApplicationContext(),HomeScreen.class));

                        } else {
                            Toast.makeText(SignUp.this, "Error has occurred " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }
                });

            }
        });


    }
    private void createRequest()
    {
        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
    }
    //google sign in function
    private void signIn()
    {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    // google sign in function
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                //Log.d(TAG, "firebaseAuthWithGoogle:" + account.getId()); --------Ignore me
                firebaseAuthWithGoogle(account.getIdToken());
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Toast.makeText(getApplicationContext(), "Google Sign in failed", Toast.LENGTH_SHORT).show();
            }
        }
    }
    //google sign in function
    private void firebaseAuthWithGoogle(String idToken)
    {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>()
                {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task)
                    {
                        if (task.isSuccessful())
                        {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(getApplicationContext(), "Google Sign in Sucessful", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                            Intent intent = new Intent(getApplicationContext(), HomeScreen.class);
                            startActivity(intent);
                        }
                        else
                        {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(getApplicationContext(), "Google Sign in failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}