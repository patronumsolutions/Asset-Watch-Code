package com.example.assetwatch_v1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeScreen extends AppCompatActivity {

    // Splash-screen only on first startup

    SharedPreferences sharedPreferences;
    Boolean firstTime;

    // Variables

    Animation topAnim, bottomAnim;
    TextView assetwatch, slogan;
    LinearLayout slogan_line;
    ImageView IV_Logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Animations
        topAnim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);

        // Hooks

        assetwatch = findViewById(R.id.TV_AssetWatch);
        slogan = findViewById(R.id.TV_Slogan);
        slogan_line = findViewById(R.id.LL_SloganLine);
        IV_Logo = findViewById(R.id.IV_Logo);

        assetwatch.setAnimation(topAnim);
        slogan .setAnimation(bottomAnim);
        slogan_line.setAnimation(bottomAnim);
        IV_Logo.setAnimation(topAnim);

        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        firstTime = sharedPreferences.getBoolean("firstTime", true);

        if(firstTime) {
            new Handler().postDelayed(() -> {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                firstTime = false;
                editor.putBoolean("firstTime", false);
                editor.apply();

                Intent intent = new Intent(WelcomeScreen.this, HomeScreen.class);
                startActivity(intent);
                finish();
            }, 3000);
        }
        else {
            Intent intent = new Intent(WelcomeScreen.this, HomeScreen.class);
            startActivity(intent);
            finish();
        }
    }
}
