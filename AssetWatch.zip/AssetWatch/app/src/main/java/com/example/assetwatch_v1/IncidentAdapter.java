package com.example.assetwatch_v1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class IncidentAdapter extends RecyclerView.Adapter<IncidentAdapter.MyViewHolder> {

    Context context;
    ArrayList<IncidentModel> incident_list;

    public IncidentAdapter(Context context, ArrayList<IncidentModel> incident_list) {
        this.context = context;
        this.incident_list = incident_list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.incident_list_item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        IncidentModel incidentModel = incident_list.get(position);
        //holder.id.setText(incidentModel.getId());
        holder.date.setText(incidentModel.getDate());
        holder.description.setText(incidentModel.getIncident_Desc());
    }

    @Override
    public int getItemCount() {
        return incident_list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView id, date, description;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            id = itemView.findViewById(R.id.TV_IncidentID);
            date = itemView.findViewById(R.id.TV_IncidentDate);
            description = itemView.findViewById(R.id.TV_IncidentDesc);
        }
    }
}
