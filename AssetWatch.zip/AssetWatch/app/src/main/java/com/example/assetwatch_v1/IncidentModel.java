package com.example.assetwatch_v1;

import android.widget.RadioButton;

import java.sql.Time;
import java.util.Date;

public class IncidentModel {
    int id;
    String date;
    String time;
    String location;
    String incident_Desc;


    public IncidentModel(String date, String time, String location, String incident_Desc) {
        this.date = date;
        this.time = time;
        this.location = location;
        this.incident_Desc = incident_Desc;
    }

    public IncidentModel() {}

    @Override
    public String toString() {
        return "IncidentModel{" +
                "id=" + id +
                ", DateTime='" + date + '\'' +
                ", Time=" + time +
                ", Location=" + location +
                ", Incident_Desc=" + incident_Desc +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getIncident_Desc() {
        return incident_Desc;
    }

    public void setIncident_Desc(String incident_Desc) {
        this.incident_Desc = incident_Desc;
    }

}
