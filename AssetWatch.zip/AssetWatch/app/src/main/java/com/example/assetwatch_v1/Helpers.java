/*package com.example.assetwatch_v1;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Helpers
{
    //This is called "Regular expression and this is what is used to decipher if the password is true to the criteria set."

    public static boolean isPasswordValid(String password) {
        //The password should contain:
        //special character
        //Upper and Lowercase
        //8 Char minimum
        String regEx = "^(?:(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).*)[^\\s]{8,}$";

        Pattern pattern = Pattern.compile(regEx,Pattern.UNICODE_CASE);
        Matcher matcher = pattern.matcher(password);

        return matcher.matches(); //Simplified if else.
    }

    // Regular expression for email
    public static boolean isEmailValid(String email) // Something about the email validation is not working.
    {
        // makes sure email has @ and doesn't contain "..com" (for example)
        String emailFormate = "/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$/";
        Pattern p = Pattern.compile(emailFormate);
        if (email == null) {
            return false;
        } else {
            p.matcher(email).matches();
            return true;
        }
    }
}*/
