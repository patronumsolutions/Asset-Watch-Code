package com.example.assetwatch_v1;

public class SupplierModel {

    private String supp_Name;
    private String trade_num;
    private String phone;
    private String email;
    private String address;
    private String website;

    public SupplierModel(String supp_name, String trade_num, String email, String phone, String address, String website) {
        this.supp_Name = supp_name;
        this.trade_num = trade_num;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.website = website;
    }

    public SupplierModel() {}

    @Override
    public String toString() {
        return "SupplierModel{" +
                ", supplier name='" + supp_Name + '\'' +
                ", email=" + email +
                ", trade_num=" + trade_num +
                ", phone=" + phone +
                ", address=" + address +
                ", website=" + website +
                '}';
    }

    public String getSupp_name() {
        return supp_Name;
    }

    public void setSupp_name(String supp_name) {
        this.supp_Name = supp_name;
    }

    public String getTrade_num() {
        return trade_num;
    }

    public void setTrade_num(String trade_num) {
        this.trade_num = trade_num;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }
}
