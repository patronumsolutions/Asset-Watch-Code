package com.example.assetwatch_v1;

public class AssetModel {

    private String brand_name;
    private String serial_num;
    private String purchase_date;
    private String purchase_price;

    // constructors

    public AssetModel(String brand_name, String serial_num, String purchase_date, String purchase_price) {
        this.brand_name = brand_name;
        this.serial_num = serial_num;
        this.purchase_date = purchase_date;
        this.purchase_price = purchase_price;
    }

    public AssetModel() {}

    // toString is necessary for printing the contents of a class object

    @Override
    public String toString() {
        return "AssetModel{" +
                "brand_name=" + brand_name +
                ", serial_num='" + serial_num + '\'' +
                ", purchase_date=" + purchase_date +
                ", purchase_price=" + purchase_price + '}';
    }

    // getters and setters

    public String getBrand_name() {
        return brand_name;
    }

    public void setBrand_name(String brand_name) {
        this.brand_name = brand_name;
    }

    public String getSerial_num() {
        return serial_num;
    }

    public void setSerial_num(String serial_num) {
        this.serial_num = serial_num; }

    public String getPurchase_date() {
        return purchase_date;
    }

    public void setPurchase_date(String purchase_date) {
        this.purchase_date = purchase_date; }

    public String getPurchase_price() {
        return purchase_price;
    }

    public void setPurchase_price(String purchase_price) {
        this.purchase_price = purchase_price; }
}