package com.example.assetwatch_v1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;


public class HomeScreen extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    LinearLayout LL_AddAsset, LL_AddSupplier, LL_IncidentList, LL_AddIncident, LL_SupplierList, LL_AssetList;
    private DrawerLayout drawer;
    private FirebaseAuth mFirebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        // Hooks

        LL_AddAsset = findViewById(R.id.LL_AddAsset);
        LL_AddSupplier = findViewById(R.id.LL_AddSupplier);
        LL_SupplierList = findViewById(R.id.LL_SupplierList);
        LL_AssetList = findViewById(R.id.LL_AssetList);
        LL_AddIncident = findViewById(R.id.LL_AddIncident);
        LL_IncidentList = findViewById(R.id.LL_IncidentList);

        LL_AddAsset.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), AddAsset.class)));
        LL_AssetList.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), AssetList.class)));
        LL_SupplierList.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), SupplierList.class)));
        LL_AddIncident.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), Add_Incident.class)));
        LL_AddSupplier.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), AddSupplier.class)));
        LL_IncidentList.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), IncidentList.class)));


    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_profile:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer,
                        new Profile()).commit();
                break;
            case R.id.nav_SignOut:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer,
                new SignOut()).commit();
                break;
            case R.id.nav_share:
                gotoUrl("https://drive.google.com/drive/folders/1WhR_kqoLL6Ag4rl5Ob5dxPC_W-lZfJkB?usp=sharing");
                break;

        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }  else{
            super.onBackPressed();
        }
        super.onBackPressed();
    }
}