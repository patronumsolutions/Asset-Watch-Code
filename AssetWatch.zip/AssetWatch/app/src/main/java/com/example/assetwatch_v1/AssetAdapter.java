package com.example.assetwatch_v1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AssetAdapter extends RecyclerView.Adapter<AssetAdapter.MyViewHolder> {

    Context context;
    ArrayList<AssetModel> asset_list;

    public AssetAdapter(Context context, ArrayList<AssetModel> asset_list) {
        this.context = context;
        this.asset_list = asset_list;
    }

    @NonNull
    @Override
    public AssetAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.asset_list_item, parent, false);
        return new AssetAdapter.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AssetAdapter.MyViewHolder holder, int position) {

        AssetModel assetModel = asset_list.get(position);
        holder.brand.setText(assetModel.getBrand_name());
        holder.serial_num.setText(assetModel.getSerial_num());
        holder.purchase_price.setText(assetModel.getPurchase_price());
    }

    @Override
    public int getItemCount() {
        return asset_list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView brand, serial_num, purchase_price;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            brand = itemView.findViewById(R.id.TV_AssetBrand);
            serial_num = itemView.findViewById(R.id.TV_AssetSerialNum);
            purchase_price = itemView.findViewById(R.id.TV_PurchasePrice);
        }
    }
}