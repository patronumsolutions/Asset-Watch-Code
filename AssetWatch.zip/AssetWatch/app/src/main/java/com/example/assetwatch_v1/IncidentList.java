package com.example.assetwatch_v1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class IncidentList extends AppCompatActivity {

    RecyclerView recyclerView;
    DatabaseReference DBref;
    IncidentAdapter myAdapter;
    ArrayList<IncidentModel> incidentlist;
    ImageView IV_BackArrow;
    FloatingActionButton FAB_Add_Incident;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.incident_list);

        IV_BackArrow = findViewById(R.id.IV_BackArrow);
        IV_BackArrow.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), HomeScreen.class)));

        FAB_Add_Incident = (FloatingActionButton) findViewById(R.id.FAB_Add_Incident);
        FAB_Add_Incident.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), Add_Incident.class)));

        recyclerView = findViewById(R.id.RV_Incidents);
        DBref = FirebaseDatabase.getInstance().getReference("Incidents");
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        incidentlist = new ArrayList<>();
        myAdapter = new IncidentAdapter(this, incidentlist);
        recyclerView.setAdapter(myAdapter);

        DBref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    IncidentModel incidentModel = dataSnapshot.getValue(IncidentModel.class);
                    incidentlist.add(incidentModel);
                }
                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}