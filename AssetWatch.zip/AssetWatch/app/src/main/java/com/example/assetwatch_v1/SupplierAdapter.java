package com.example.assetwatch_v1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SupplierAdapter extends RecyclerView.Adapter<SupplierAdapter.SupplierViewHolder> {

    Context context;
    ArrayList<SupplierModel> supplier_list;

    public SupplierAdapter(Context context, ArrayList<SupplierModel> supplier_list) {
        this.context = context;
        this.supplier_list = supplier_list;
    }

    @NonNull
    @Override
    public SupplierViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.supplier_list_item, parent, false);
        return new SupplierViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull SupplierViewHolder holder, int position) {

        SupplierModel supplierModel = supplier_list.get(position);
        holder.supp_name.setText(supplierModel.getSupp_name());
        holder.phone_num.setText(supplierModel.getPhone());
    }

    @Override
    public int getItemCount() {
        return supplier_list.size();
    }

    public static class SupplierViewHolder extends RecyclerView.ViewHolder {

        TextView supp_name, phone_num;

        public SupplierViewHolder(@NonNull View itemView) {
            super(itemView);

            supp_name = itemView.findViewById(R.id.TV_SupplierName);
            phone_num = itemView.findViewById(R.id.TV_SupplierPhone);

        }
    }
}

