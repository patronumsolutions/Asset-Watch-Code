package com.example.assetwatch_v1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddAsset extends AppCompatActivity {

    EditText ET_Brand, ET_SerialNum, ET_PurchaseDate, ET_PurchasePrice;
    Button btn_AddAsset;
    ImageView IV_BackArrow;
    FirebaseAuth mAuth;
    DatabaseReference userDBRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_asset);

        // Hooks
        ET_Brand = (EditText) findViewById(R.id.ET_Brand);
        ET_SerialNum = (EditText) findViewById(R.id.ET_SerialNum);
        ET_PurchaseDate = (EditText) findViewById(R.id.ET_PurchaseDate);
        ET_PurchasePrice = (EditText) findViewById(R.id.ET_PurchasePrice);
        IV_BackArrow = (ImageView) findViewById(R.id.IV_BackArrow);
        btn_AddAsset = (Button) findViewById(R.id.btn_AddAsset);

        userDBRef = FirebaseDatabase.getInstance("https://assetwatch-v1-f95c0-default-rtdb.firebaseio.com/").getReference().child("Assets");


        btn_AddAsset.setOnClickListener(v -> {
            insertAssetData();
            startActivity(new Intent(getApplicationContext(), AssetList.class));
        });


        // OnClick Listeners

        IV_BackArrow.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), HomeScreen.class)));

    }

    // Create insertUserData method.

    private void insertAssetData() {

        String Brand_name = ET_Brand.getText().toString();
        String Serial_num = ET_SerialNum.getText().toString();
        String Purchase_date = ET_PurchaseDate.getText().toString();
        String Purchase_price = ET_PurchasePrice.getText().toString();

        AssetModel assetModel = new AssetModel(Brand_name, Serial_num, Purchase_date, Purchase_price);

        userDBRef.push().setValue(assetModel);
        Toast.makeText(AddAsset.this, "Asset Registered", Toast.LENGTH_SHORT).show();
    }
}
