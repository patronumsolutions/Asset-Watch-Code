package com.example.assetwatch_v1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class nav_activity_main extends AppCompatActivity {

    LinearLayout LL_AddAsset, LL_AddSupplier, LL_IncidentList, LL_AddIncident, LL_SupplierList, LL_AssetList;
    //ImageView IV_LeftSwipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_activity_main);

        // Hooks

        LL_AddAsset = findViewById(R.id.LL_AddAsset);
        LL_AddSupplier = findViewById(R.id.LL_AddSupplier);
        LL_SupplierList = findViewById(R.id.LL_SupplierList);
        LL_AssetList = findViewById(R.id.LL_AssetList);
        LL_AddIncident = findViewById(R.id.LL_AddIncident);
        LL_IncidentList = findViewById(R.id.LL_IncidentList);
        //IV_LeftSwipe = findViewById(R.id.IV_LeftSwipe);

        //IV_LeftSwipe.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), HomeScreen.class)));
        LL_AddAsset.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), AddAsset.class)));
        LL_AssetList.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), AssetList.class)));
        LL_SupplierList.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), SupplierList.class)));
        LL_AddIncident.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), Add_Incident.class)));
        LL_AddSupplier.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), AddSupplier.class)));
        LL_IncidentList.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), IncidentList.class)));


    }
}