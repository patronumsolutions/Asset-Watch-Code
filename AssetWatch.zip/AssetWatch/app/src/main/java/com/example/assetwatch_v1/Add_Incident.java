package com.example.assetwatch_v1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Add_Incident extends AppCompatActivity {
    EditText ET_Date_of_Incident, ET_TimeIncident, ET_LocationIncident,  ET_IncidentDesc;
    Button btn_AddIncident, btn_Email;
    ImageView IV_BackArrow;
    DatabaseReference userDBRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_incident);

        ET_Date_of_Incident = (EditText) findViewById(R.id.ET_Date_of_Incident);
        ET_TimeIncident = (EditText) findViewById(R.id.ET_TimeIncident);
        ET_LocationIncident = (EditText) findViewById(R.id.ET_LocationIncident);
        ET_IncidentDesc = (EditText) findViewById(R.id.ET_IncidentDesc);
        btn_Email = (Button) findViewById(R.id.btn_Email);
        IV_BackArrow = (ImageView) findViewById(R.id.IV_BackArrow);
        btn_AddIncident = (Button) findViewById(R.id.btn_AddIncident);

        btn_Email.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), Email.class)));


        IV_BackArrow.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), HomeScreen.class)));

        // Save data in firebase on button click.

        userDBRef = FirebaseDatabase.getInstance("https://assetwatch-v1-f95c0-default-rtdb.firebaseio.com/").getReference().child("Incidents");

        btn_AddIncident.setOnClickListener(v -> {
            insertIncidentData();
            startActivity(new Intent(getApplicationContext(), IncidentList.class));
        });

    }
    private void insertIncidentData() {

        String date = ET_Date_of_Incident.getText().toString();
        String time = ET_TimeIncident.getText().toString();
        String location = ET_LocationIncident.getText().toString();
        String description = ET_IncidentDesc.getText().toString();


        IncidentModel incidentModel = new IncidentModel(date, time, location, description);

        userDBRef.push().setValue(incidentModel);
        Toast.makeText(Add_Incident.this, "Incident Logged", Toast.LENGTH_SHORT).show();
    }
}